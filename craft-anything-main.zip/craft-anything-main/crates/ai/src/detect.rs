//! Find AI that's ready to use on this machine: env keys, local servers (also those set up in
//! OpenCode), agent CLIs, ssh hosts. Probes run in parallel and the whole scan is bounded (about a
//! second).

use crate::openai::{LOCAL_SERVERS, OpenAi};
use crate::{BackendConfig, BackendKind, Detected};
use craft_anything_evidence::ErrorCode;
use std::net::{SocketAddr, TcpStream, ToSocketAddrs};
use std::path::PathBuf;
use std::sync::mpsc;
use std::time::{Duration, Instant};

/// Per-server connect bound.
pub const PROBE: Duration = Duration::from_millis(300);
/// Whole-scan bound.
pub const TOTAL: Duration = Duration::from_millis(1500);

fn cfg(name: &str, kind: BackendKind, model: &str) -> BackendConfig {
    BackendConfig { name: name.into(), kind, model: model.into(), base_url: None, ssh_host: None, enabled: true }
}

fn cfg_at(name: &str, kind: BackendKind, model: &str, base: &str) -> BackendConfig {
    BackendConfig { base_url: Some(base.into()), ..cfg(name, kind, model) }
}

/// Environment keys that are set.
pub fn env_keys(get: impl Fn(&str) -> Option<String>) -> Vec<Detected> {
    let mut out = Vec::new();
    for (var, name, kind, model) in [
        ("ANTHROPIC_API_KEY", "Claude", BackendKind::Anthropic, crate::anthropic::DEFAULT_MODEL),
        ("OPENAI_API_KEY", "OpenAI", BackendKind::Openai, crate::openai::OPENAI_DEFAULT_MODEL),
        ("OPENROUTER_API_KEY", "OpenRouter", BackendKind::Openrouter, crate::openai::OPENROUTER_DEFAULT_MODEL),
    ] {
        if get(var).is_some_and(|v| !v.trim().is_empty()) {
            out.push(Detected { suggestion: cfg(name, kind, model), reason: format!("Found {var} in your environment"), needs_key: false });
        }
    }
    // Hosted APIs we know by name. Offered only when their key is already set, like OpenAI and
    // Anthropic, so a paid service is never advertised to someone who has no key for it.
    for p in crate::providers::PROVIDERS {
        if let Some(var) = p.key_names().find(|var| get(var).is_some_and(|v| !v.trim().is_empty())) {
            out.push(Detected {
                suggestion: cfg_at(p.name, p.kind, p.default_model, p.base_url),
                reason: format!("Found {var} in your environment"),
                needs_key: false,
            });
        }
    }
    // A Google AI Studio key is free and the easiest one to get (#646): always offered, found or pasted.
    let gemini = get("GEMINI_API_KEY").is_some_and(|v| !v.trim().is_empty());
    out.push(Detected {
        suggestion: cfg(GEMINI_NAME, BackendKind::Gemini, crate::openai::GEMINI_DEFAULT_MODEL),
        reason: if gemini {
            "Found GEMINI_API_KEY in your environment".into()
        } else {
            "Gemini: paste a free key from Google AI Studio (aistudio.google.com/apikey)".into()
        },
        needs_key: !gemini,
    });
    // Kimi K3.1 Pro builds through OpenRouter: with its key found, or one the person pastes.
    let found = get("OPENROUTER_API_KEY").is_some_and(|v| !v.trim().is_empty());
    out.push(Detected {
        suggestion: cfg(KIMI_NAME, BackendKind::Openrouter, crate::openai::KIMI_K3_1),
        reason: if found {
            "Kimi K3.1 Pro through OpenRouter, with the OPENROUTER_API_KEY in your environment".into()
        } else {
            "Kimi K3.1 Pro through OpenRouter: paste your OpenRouter key".into()
        },
        needs_key: !found,
    });
    // OpenCode Go: a paid subscription, so it is offered only when its key is already set. Gemini
    // and Kimi are offered keyless because they are general model APIs.
    let go = ["OPENCODEGO_API_KEY", "OPENCODE_GO_API_KEY"].iter().any(|v| get(v).is_some_and(|k| !k.trim().is_empty()));
    if go {
        out.push(Detected {
            suggestion: cfg_at(OPENCODE_GO_NAME, BackendKind::OpenaiCompatible, crate::openai::OPENCODE_GO_DEFAULT_MODEL, crate::openai::OPENCODE_GO_BASE),
            reason: "OpenCode Go, with its key in your environment".into(),
            needs_key: false,
        });
    }
    out
}

/// The name Kimi K3.1 Pro is added under.
pub const KIMI_NAME: &str = "Kimi K3.1 Pro (OpenRouter)";
/// Name given to a Google AI Studio (Gemini API key) backend.
pub const GEMINI_NAME: &str = "Gemini (Google AI Studio)";

/// The name OpenCode Go is added under.
pub const OPENCODE_GO_NAME: &str = "OpenCode Go (subscription)";

/// Is something listening at this URL's host:port? (bounded TCP connect)
pub fn port_open(base_url: &str, timeout: Duration) -> bool {
    let hostport = base_url.split("://").nth(1).unwrap_or(base_url).split('/').next().unwrap_or_default();
    let addrs: Vec<SocketAddr> = hostport.to_socket_addrs().map(|a| a.collect()).unwrap_or_default();
    addrs.iter().any(|a| TcpStream::connect_timeout(a, timeout).is_ok())
}

/// Task tokens and known model families that turn text into numbers, rank or transcribe.
/// Match the model name, not its publisher: `matts/llama-3-instruct` can chat (#127).
const NOT_CHAT: &[&str] = &["embed", "embedding", "embeddings", "embeddinggemma", "minilm", "bge", "rerank", "reranker", "whisper", "tts", "xtts"];

/// The first model a server lists that can chat. A specialised model isn't a chat fallback.
pub(crate) fn chat_model(models: &[String]) -> Option<String> {
    models.iter().find(|m| can_chat(m)).cloned()
}

/// Every model a server lists that can chat, in its order.
pub(crate) fn chat_models(models: &[String]) -> Vec<String> {
    models.iter().filter(|m| can_chat(m)).cloned().collect()
}

/// Whether a model's name says it can chat: not an embedding, ranking or speech model.
fn can_chat(model: &str) -> bool {
    let specialised =
        |name: &str| name.split(|c: char| !c.is_ascii_alphanumeric()).any(|token| NOT_CHAT.contains(&token.trim_end_matches(|c: char| c.is_ascii_digit())));
    let lower = model.to_ascii_lowercase();
    let (directory, name) = lower.rsplit_once(['/', '\\']).unwrap_or(("", lower.as_str()));
    // A generic GGUF filename needs its model directory; arbitrary ancestors do not identify it.
    let generic_gguf = name == "model.gguf" || name == "ggml-model.gguf" || (name.starts_with("ggml-model-") && name.ends_with(".gguf"));
    let model_directory = directory.rsplit(['/', '\\']).next().unwrap_or_default();
    !(specialised(name) || generic_gguf && specialised(model_directory))
}

/// One local server: connect, then list models.
pub fn probe_local(label: &str, base: &str) -> Option<Detected> {
    if !port_open(base, PROBE) {
        return None;
    }
    let models = match OpenAi::compatible(label, base, None, "").list_models(Duration::from_millis(700)) {
        Ok(m) => m,
        // Something else listens there (another app's web server on 8080 answering 404): no model
        // server, so chats with it could only fail (#30).
        Err(e) if e.code == ErrorCode::GarbledOutput || e.details.as_ref().is_some_and(|d| d.get("status").is_some()) => return None,
        // No answer in time: it may still be loading a model.
        Err(_) => Vec::new(),
    };
    // A model the server has loaded comes first: LM Studio's list holds every model downloaded,
    // FastFlowLM's every model it can download, and asking for another loads or downloads it (#1434).
    let loaded = if models.is_empty() { None } else { chat_model(&OpenAi::compatible(label, base, None, "").loaded_models(Duration::from_millis(700))) };
    let model = match loaded.or_else(|| chat_model(&models)) {
        Some(model) => model,
        None if models.is_empty() => String::new(),
        None => return None,
    };
    let reason = match models.len() {
        0 => format!("Found {label} running at {base}"),
        1 => format!("Found {label} running with 1 model"),
        n => format!("Found {label} running with {n} models"),
    };
    let mut c = cfg(&format!("{label} (local)"), BackendKind::OpenaiCompatible, &model);
    c.base_url = Some(base.to_string());
    Some(Detected { suggestion: c, reason, needs_key: false })
}

/// Agent CLIs on PATH.
pub fn agent_clis() -> Vec<Detected> {
    crate::cli_agents::KNOWN
        .iter()
        .filter_map(|(id, prog, display)| {
            crate::cli_agents::find_program(prog).map(|p| Detected {
                suggestion: cfg(display, BackendKind::AgentCli, id),
                reason: format!("Found {display} at {}", p.display()),
                needs_key: false,
            })
        })
        .collect()
}

/// What a scan found that isn't an AI to use but explains why one is missing.
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum DetectHint {
    /// The Claude desktop app is installed, but not Claude Code, the `claude` command builds run:
    /// "Claude" installed from its website wasn't found and nothing said why (#259).
    ClaudeDesktopWithoutCli { app: PathBuf },
}

impl DetectHint {
    pub fn message(&self) -> String {
        match self {
            Self::ClaudeDesktopWithoutCli { app } => {
                format!("The Claude desktop app is installed ({}), but Claude Code, the `claude` command-line tool building uses, isn't.", app.display())
            }
        }
    }

    pub fn remediation(&self) -> &'static str {
        match self {
            Self::ClaudeDesktopWithoutCli { .. } => "Install Claude Code apart from the desktop app, sign in to it once in a terminal, then look again.",
        }
    }
}

/// Hints for what [`agent_clis`] can't offer.
pub fn hints() -> Vec<DetectHint> {
    if crate::cli_agents::find_program("claude").is_some() {
        return Vec::new();
    }
    let home = std::env::var_os(if cfg!(windows) { "USERPROFILE" } else { "HOME" }).map(PathBuf::from);
    let local_data = std::env::var_os("LOCALAPPDATA").map(PathBuf::from);
    claude_desktop_app(home.as_deref(), local_data.as_deref()).map(|app| DetectHint::ClaudeDesktopWithoutCli { app }).into_iter().collect()
}

/// The Claude desktop app's Store package family (name and publisher id), whose folder Windows
/// makes under `%LOCALAPPDATA%\Packages` for each person it's installed for.
const CLAUDE_STORE_PACKAGE: &str = "Claude_pzs8sxrjxfjjc";

/// Where the Claude desktop app is, if it's installed. On Windows the Store package leaves a
/// `claude-desktop` app alias (a link that only `symlink_metadata` can read), or, with its app
/// aliases turned off, only its package folder; the older installer leaves an `AnthropicClaude`
/// folder. On macOS it's `Claude.app`. There's no Linux app.
fn claude_desktop_app(home: Option<&std::path::Path>, local_data: Option<&std::path::Path>) -> Option<PathBuf> {
    let places: Vec<PathBuf> = if cfg!(windows) {
        let local_data = local_data.map(PathBuf::from).or_else(|| home.map(|h| h.join("AppData").join("Local")));
        local_data
            .into_iter()
            .flat_map(|d| {
                [
                    d.join("Microsoft").join("WindowsApps").join("claude-desktop.exe"),
                    d.join("AnthropicClaude").join("claude.exe"),
                    d.join("Packages").join(CLAUDE_STORE_PACKAGE),
                ]
            })
            .collect()
    } else if cfg!(target_os = "macos") {
        std::iter::once(PathBuf::from("/Applications/Claude.app")).chain(home.map(|h| h.join("Applications").join("Claude.app"))).collect()
    } else {
        Vec::new()
    };
    places.into_iter().find(|p| std::fs::symlink_metadata(p).is_ok())
}

/// The most servers taken from OpenCode's settings.
const OPENCODE_MAX: usize = 6;

/// Where OpenCode keeps its settings (as setup registers it): `OPENCODE_CONFIG`, else
/// `opencode.jsonc` or `opencode.json` in `$XDG_CONFIG_HOME/opencode` (`~/.config/opencode`).
fn opencode_config(var: impl Fn(&str) -> Option<String>, home: Option<PathBuf>) -> Option<PathBuf> {
    if let Some(p) = var("OPENCODE_CONFIG").filter(|p| !p.trim().is_empty()) {
        return Some(PathBuf::from(p));
    }
    let dir = var("XDG_CONFIG_HOME").map(PathBuf::from).or_else(|| home.map(|h| h.join(".config")))?.join("opencode");
    ["opencode.jsonc", "opencode.json"].iter().map(|n| dir.join(n)).find(|p| p.is_file())
}

/// The OpenAI-compatible servers OpenCode's settings name on this computer or its network
/// (`provider.<id>.options.baseURL`), as (name, base URL): one on another port or machine is
/// offered too (#83, #73). Hosted services are left out; they need a key this scan doesn't have.
pub fn opencode_servers(text: &str) -> Vec<(String, String)> {
    let Ok(doc) = craft_anything_formats::jsonc::parse(text, false) else { return Vec::new() };
    let config = doc.to_value();
    let Some(providers) = config.get("provider").and_then(serde_json::Value::as_object) else { return Vec::new() };
    providers
        .iter()
        .filter_map(|(id, p)| {
            let base = p.pointer("/options/baseURL")?.as_str()?.trim().trim_end_matches('/');
            let name = p.get("name").and_then(serde_json::Value::as_str).filter(|n| !n.trim().is_empty()).unwrap_or(id);
            on_this_network(base).then(|| (format!("{} from OpenCode", name.trim()), base.to_string()))
        })
        .take(OPENCODE_MAX)
        .collect()
}

/// Name endings kept for local networks, which public DNS never answers.
const LAN_SUFFIXES: &[&str] = &[".local", ".lan", ".home.arpa", ".internal"];

/// An http(s) address on this computer or its local network: a private or loopback IP, or a name
/// that only a local network can answer (`localhost`, a bare name such as Docker's `ollama`, or a
/// [`LAN_SUFFIXES`] name). Nothing is looked up.
pub(crate) fn on_this_network(url: &str) -> bool {
    let Some(rest) = url.strip_prefix("http://").or_else(|| url.strip_prefix("https://")) else { return false };
    let host = rest.split('/').next().unwrap_or_default();
    // `[::1]:1234`, `127.0.0.1:1234` or `name:1234`.
    let host = match host.strip_prefix('[') {
        Some(v6) => v6.split(']').next().unwrap_or_default(),
        None => host.rsplit_once(':').map_or(host, |(h, _)| h),
    };
    match host.parse::<std::net::IpAddr>() {
        Ok(std::net::IpAddr::V4(ip)) => ip.is_loopback() || ip.is_private() || ip.is_link_local(),
        Ok(std::net::IpAddr::V6(ip)) => ip.is_loopback() || ip.is_unique_local() || ip.is_unicast_link_local(),
        Err(_) => {
            let host = host.to_ascii_lowercase();
            !host.is_empty() && (!host.contains('.') || LAN_SUFFIXES.iter().any(|s| host.ends_with(s)))
        }
    }
}

/// The ports just above LM Studio's 1234, where its server goes when 1234 is taken or the person
/// moved it (#73: 1235). Whatever answers there is checked like any other server: it must speak
/// the OpenAI API and list models.
const LM_STUDIO_NEARBY: std::ops::RangeInclusive<u16> = 1235..=1239;

/// Where LM Studio keeps its server settings, under the home folder (newer, then older versions).
/// Taken from LM Studio's own folders as they were seen, not from its documentation.
const LM_STUDIO_SETTINGS: &[&str] = &[".lmstudio/.internal/http-server-config.json", ".cache/lm-studio/.internal/http-server-config.json"];

/// The server port in LM Studio's settings file (`"port": 1235`).
pub(crate) fn lmstudio_port(text: &str) -> Option<u16> {
    let doc = craft_anything_formats::jsonc::parse(text, false).ok()?.to_value();
    doc.get("port").and_then(serde_json::Value::as_u64).and_then(|p| u16::try_from(p).ok()).filter(|p| *p != 0)
}

/// Every local server to probe: the usual addresses, the port LM Studio's settings name, those
/// OpenCode names elsewhere, then the ports next to LM Studio's. Each address once, under the most
/// specific name.
fn local_servers() -> Vec<(String, String)> {
    let read = |p: &std::path::Path| std::fs::metadata(p).ok().filter(|m| m.len() <= 1024 * 1024).and_then(|_| std::fs::read_to_string(p).ok());
    let home = dirs::home_dir();
    let lm_port = home.iter().flat_map(|h| LM_STUDIO_SETTINGS.iter().map(move |f| h.join(f))).find_map(|p| read(&p).as_deref().and_then(lmstudio_port));
    let opencode = opencode_config(|v| std::env::var(v).ok(), home).and_then(|p| read(&p)).as_deref().map(opencode_servers).unwrap_or_default();
    servers_to_probe(lm_port, opencode)
}

/// [`local_servers`] without the files: `lm_port` is the port LM Studio's settings name, and
/// `opencode` the servers OpenCode's settings name.
fn servers_to_probe(lm_port: Option<u16>, opencode: Vec<(String, String)>) -> Vec<(String, String)> {
    let mut all: Vec<(String, String)> = LOCAL_SERVERS.iter().map(|(l, b)| (l.to_string(), b.to_string())).collect();
    let extra = lm_port
        .map(|p| ("LM Studio".to_string(), format!("http://127.0.0.1:{p}/v1")))
        .into_iter()
        .chain(opencode)
        .chain(LM_STUDIO_NEARBY.map(|p| (format!("AI server on port {p}"), format!("http://127.0.0.1:{p}/v1"))));
    for (label, base) in extra {
        if !all.iter().any(|(_, b)| b.trim_end_matches('/') == base.trim_end_matches('/')) {
            all.push((label, base));
        }
    }
    all
}

/// Everything, bounded by [`TOTAL`].
pub fn detect_all() -> Vec<Detected> {
    let start = Instant::now();
    let (tx, rx) = mpsc::channel::<(usize, Vec<Detected>)>();
    let mut jobs = 0usize;
    for (i, (label, base)) in local_servers().into_iter().enumerate() {
        let tx = tx.clone();
        if std::thread::Builder::new()
            .name("ai-detect".into())
            .spawn(move || {
                let _ = tx.send((i + 10, probe_local(&label, &base).into_iter().collect()));
            })
            .is_ok()
        {
            jobs += 1;
        }
    }
    {
        let tx = tx.clone();
        if std::thread::Builder::new()
            .name("ai-detect".into())
            .spawn(move || {
                let _ = tx.send((5, agent_clis()));
            })
            .is_ok()
        {
            jobs += 1;
        }
    }
    drop(tx);
    let mut parts: Vec<(usize, Vec<Detected>)> = vec![(0, env_keys(|v| std::env::var(v).ok()))];
    while jobs > 0 {
        let left = TOTAL.saturating_sub(start.elapsed());
        match rx.recv_timeout(left) {
            Ok(p) => {
                parts.push(p);
                jobs -= 1;
            }
            Err(_) => break,
        }
    }
    let mut hosts = crate::ssh::ssh_hosts();
    hosts.truncate(5);
    let ssh: Vec<Detected> = hosts.into_iter().flat_map(remote_agents).collect();
    parts.push((100, ssh));
    parts.sort_by_key(|(i, _)| *i);
    parts.into_iter().flat_map(|(_, v)| v).collect()
}

/// SSH aliases are suggestions, not proof that an agent is installed there.
fn remote_agents(host: String) -> Vec<Detected> {
    [("claude-code", "Claude Code"), ("opencode", "OpenCode")]
        .into_iter()
        .map(|(id, label)| {
            let mut c = cfg(&format!("{label} on {host}"), BackendKind::AgentCli, id);
            c.ssh_host = Some(host.clone());
            Detected { suggestion: c, reason: format!("SSH host {host} from ~/.ssh/config (check that {label} is installed there)"), needs_key: false }
        })
        .collect()
}

#[cfg(test)]
mod model_id_tests;

#[cfg(test)]
mod tests {
    use super::*;

    /// #259: the desktop app is found where its installers put it, and nothing is made up where
    /// there's none.
    #[test]
    fn the_claude_desktop_app_is_found_where_its_installers_put_it() {
        let empty = tempfile::tempdir().unwrap();
        let dir = tempfile::tempdir().unwrap();
        let app = dir.path().join("AnthropicClaude").join("claude.exe");
        std::fs::create_dir_all(app.parent().unwrap()).unwrap();
        std::fs::write(&app, b"app").unwrap();
        let mac = dir.path().join("Applications").join("Claude.app");
        std::fs::create_dir_all(&mac).unwrap();
        let found = claude_desktop_app(Some(dir.path()), Some(dir.path()));
        if cfg!(windows) {
            assert_eq!(found, Some(app));
            assert_eq!(claude_desktop_app(Some(empty.path()), Some(empty.path())), None);
            // The Store package's alias wins over an old install.
            let alias = dir.path().join("Microsoft").join("WindowsApps").join("claude-desktop.exe");
            std::fs::create_dir_all(alias.parent().unwrap()).unwrap();
            std::fs::write(&alias, b"").unwrap();
            assert_eq!(claude_desktop_app(None, Some(dir.path())), Some(alias));
            // A Store install whose app aliases are turned off leaves only its package folder.
            let store = tempfile::tempdir().unwrap();
            let package = store.path().join("Packages").join(CLAUDE_STORE_PACKAGE);
            std::fs::create_dir_all(&package).unwrap();
            assert_eq!(claude_desktop_app(None, Some(store.path())), Some(package));
        } else if cfg!(target_os = "linux") {
            assert_eq!(found, None, "there's no Claude desktop app for Linux");
        }
        let hint = DetectHint::ClaudeDesktopWithoutCli { app: PathBuf::from("Claude") };
        assert!(hint.message().contains("desktop app") && hint.message().contains("`claude`"), "{}", hint.message());
        assert_eq!(serde_json::to_value(&hint).unwrap()["kind"], "claude_desktop_without_cli");
    }

    /// Non-Git SSH hosts offer both supported agent suggestions without probing the remote computer.
    #[test]
    fn ssh_hosts_offer_opencode_as_well_as_claude_code() {
        let found = remote_agents("test-box".into());
        assert_eq!(found.iter().map(|d| d.suggestion.model.as_str()).collect::<Vec<_>>(), ["claude-code", "opencode"]);
        let oc = &found[1].suggestion;
        assert_eq!(oc.name, "OpenCode on test-box");
        assert_eq!(oc.ssh_host.as_deref(), Some("test-box"));
    }

    #[test]
    fn env_detection() {
        let d = env_keys(|v| (v == "OPENROUTER_API_KEY").then(|| "k".to_string()));
        let find = |name: &str| d.iter().find(|x| x.suggestion.name == name).unwrap_or_else(|| panic!("{name} offered"));
        assert!(find("OpenRouter").reason.contains("OPENROUTER_API_KEY"));
        // Gemini is always offered; without its key it asks for one.
        assert!(find(GEMINI_NAME).needs_key);
        // Kimi K3.1 Pro rides on the OpenRouter key, so it needs none of its own.
        assert!(!find(KIMI_NAME).needs_key);
        // A paid subscription is not advertised to someone who has no key for it.
        assert!(d.iter().all(|x| x.suggestion.name != OPENCODE_GO_NAME));
        // Without any key, everything that can be pasted is still offered.
        let none = env_keys(|_| Some("  ".into()));
        assert!(none.iter().all(|x| x.needs_key));
        for name in [GEMINI_NAME, KIMI_NAME] {
            assert!(none.iter().any(|x| x.suggestion.name == name), "{name} offered");
        }
    }

    /// OpenCode Go is offered when its key is set, under either of its environment names.
    #[test]
    fn opencode_go_is_offered_only_with_its_key() {
        for var in ["OPENCODEGO_API_KEY", "OPENCODE_GO_API_KEY"] {
            let d = env_keys(|v| (v == var).then(|| "k".to_string()));
            let go = d.iter().find(|x| x.suggestion.name == OPENCODE_GO_NAME).expect("OpenCode Go offered");
            assert!(!go.needs_key);
            assert_eq!(go.suggestion.base_url.as_deref(), Some(crate::openai::OPENCODE_GO_BASE));
            assert_eq!(go.suggestion.model.as_str(), crate::openai::OPENCODE_GO_DEFAULT_MODEL);
        }
    }

    #[test]
    fn gemini_key_in_the_environment_is_used() {
        let d = env_keys(|v| (v == "GEMINI_API_KEY").then(|| "k".to_string()));
        let g = d.iter().find(|x| x.suggestion.kind == BackendKind::Gemini).expect("Gemini offered");
        assert!(!g.needs_key && g.reason.contains("GEMINI_API_KEY"));
        assert_eq!(g.suggestion.model, crate::openai::GEMINI_DEFAULT_MODEL);
        assert!(BackendKind::Gemini.needs_key());
    }

    /// A named provider is offered when its key is set, with its own base URL and default model.
    #[test]
    fn a_provider_key_offers_that_provider() {
        let d = env_keys(|v| (v == "MOONSHOT_API_KEY").then(|| "k".to_string()));
        let p = d.iter().find(|x| x.suggestion.name == "Moonshot").expect("Moonshot offered");
        assert!(!p.needs_key);
        assert!(p.reason.contains("MOONSHOT_API_KEY"));
        assert_eq!(p.suggestion.base_url.as_deref(), Some("https://api.moonshot.ai/v1"));
        assert_eq!(p.suggestion.model.as_str(), "kimi-k3.1-pro");
        // A key that nobody has does not add a row.
        assert!(d.iter().all(|x| x.suggestion.name != "DeepSeek"));
    }

    #[test]
    fn closed_port_is_fast_and_negative() {
        // Binding port 0 chooses a nonzero port, so no listener can take this endpoint.
        let t = Instant::now();
        assert!(probe_local("X", "http://127.0.0.1:0/v1").is_none());
        assert!(t.elapsed() < Duration::from_secs(1));
    }

    /// #30: another program on a model server's port isn't offered as one.
    #[test]
    fn only_a_server_that_lists_models_is_offered() {
        use crate::tests::serve;
        assert!(probe_local("llama.cpp server", &serve("404 Not Found", "404 page not found")).is_none(), "a Go web server's 404");
        assert!(probe_local("llama.cpp server", &serve("200 OK", "<html><body>Admin</body></html>")).is_none(), "a web page");
        let found = probe_local("llama.cpp server", &serve("200 OK", r#"{"object":"list","data":[{"id":"qwen3-8b"}]}"#)).unwrap();
        assert_eq!((found.suggestion.name.as_str(), found.suggestion.model.as_str()), ("llama.cpp server (local)", "qwen3-8b"));
        assert!(probe_local("Ollama", &serve("200 OK", r#"{"object":"list","data":[]}"#)).is_some(), "running with no model yet");
    }

    /// #127: an embedding model listed first isn't the one chatted with.
    #[test]
    fn a_chat_model_is_picked_over_an_embedding_model() {
        let names = |l: &[&str]| l.iter().map(|s| s.to_string()).collect::<Vec<_>>();
        assert_eq!(chat_model(&names(&["nomic-embed-text:latest", "llama3.2:3b"])).as_deref(), Some("llama3.2:3b"));
        assert_eq!(chat_model(&names(&["mxbai-embed-large", "all-MiniLM-L6-v2", "qwen3:8b"])).as_deref(), Some("qwen3:8b"));
        assert_eq!(chat_model(&names(&["nomic-embed-text"])), None, "an embedding model cannot answer a chat request");
        assert_eq!(chat_model(&[]), None);
        let url = crate::tests::serve("200 OK", r#"{"object":"list","data":[{"id":"nomic-embed-text:latest"},{"id":"gemma3:4b"}]}"#);
        assert_eq!(probe_local("Ollama", &url).unwrap().suggestion.model, "gemma3:4b");
    }

    /// #1434: LM Studio lists every model downloaded and FastFlowLM every model it can download;
    /// Look for AI offers the one loaded (`/api/ps`, or LM Studio's `/api/v0/models`), and the
    /// first chat model listed only when nothing says what's loaded.
    #[test]
    fn look_for_ai_offers_the_loaded_model() {
        use crate::tests::serve_routes;
        const LISTED: &str = r#"{"object":"list","data":[{"id":"deepseek-r1:8b"},{"id":"gemma3:1b"},{"id":"qwen3:8b"}]}"#;
        let flm = serve_routes(&[("/v1/models", LISTED), ("/api/ps", r#"{"models":[{"name":"qwen3:8b","model":"qwen3:8b"}]}"#)]);
        assert_eq!(probe_local("FastFlowLM", &flm).unwrap().suggestion.model, "qwen3:8b");
        let studio = serve_routes(&[
            ("/v1/models", LISTED),
            (
                "/api/v0/models",
                r#"{"object":"list","data":[
                    {"id":"deepseek-r1:8b","type":"llm","state":"not-loaded"},
                    {"id":"nomic-embed-text","type":"embeddings","state":"loaded"},
                    {"id":"gemma3:1b","type":"vlm","state":"loaded"}]}"#,
            ),
        ]);
        assert_eq!(probe_local("LM Studio", &studio).unwrap().suggestion.model, "gemma3:1b", "loaded, and not the embedding model");
        // Ollama with nothing running, and a server that answers neither: the first chat model.
        let idle = serve_routes(&[("/v1/models", LISTED), ("/api/ps", r#"{"models":[]}"#)]);
        assert_eq!(probe_local("Ollama", &idle).unwrap().suggestion.model, "deepseek-r1:8b");
        let plain = serve_routes(&[("/v1/models", LISTED)]);
        assert_eq!(probe_local("llama.cpp server", &plain).unwrap().suggestion.model, "deepseek-r1:8b");
    }

    #[test]
    fn specialised_only_servers_are_not_offered_for_chat() {
        for body in [
            r#"{"object":"list","data":[{"id":"nomic-embed-text"}]}"#,
            r#"{"object":"list","data":[{"id":"bge-reranker-v2"}]}"#,
            r#"{"object":"list","data":[{"id":"whisper-large"}]}"#,
            r#"{"object":"list","data":[{"id":"tts-1"}]}"#,
            r#"{"object":"list","data":[{"id":"all-MiniLM-L6-v2"}]}"#,
        ] {
            let url = crate::tests::serve("200 OK", body);
            assert!(probe_local("Local server", &url).is_none(), "{body} has no chat model");
        }
    }

    #[test]
    fn task_markers_do_not_match_publishers_or_unrelated_words() {
        for model in ["matts/llama-3-instruct", "embedding-author/qwen-2.5-instruct", "embedded-chat", "whisper/gemma-3"] {
            assert_eq!(chat_model(&[model.into()]).as_deref(), Some(model));
        }
        let url = crate::tests::serve("200 OK", r#"{"object":"list","data":[{"id":"matts/llama-3-instruct"}]}"#);
        assert_eq!(probe_local("Local", &url).unwrap().suggestion.model, "matts/llama-3-instruct");
        for model in ["vendor/text-embedding-3-small", "nomic-embed-text:latest", "BAAI/bge-m3", "vendor/embeddinggemma-300m", "XTTS-v2"] {
            assert!(chat_model(&[model.into()]).is_none(), "{model}");
        }
    }

    /// #83: a server set up in OpenCode (here LM Studio on another port) is offered; hosted
    /// services and broken settings aren't.
    #[test]
    fn servers_set_up_in_opencode_are_offered() {
        let config = r#"{
          // LM Studio on its own port, as in #73
          "provider": {
            "lmstudio": { "name": "LM Studio", "options": { "baseURL": "http://127.0.0.1:1235/v1/" } },
            "box": { "options": { "baseURL": "http://192.168.1.20:11434/v1" } },
            "cloud": { "name": "Hosted", "options": { "baseURL": "https://api.example.com/v1" } },
            "nourl": { "name": "No address" },
          },
        }"#;
        assert_eq!(
            opencode_servers(config),
            [
                // In the order of their ids.
                ("box from OpenCode".to_string(), "http://192.168.1.20:11434/v1".to_string()),
                ("LM Studio from OpenCode".to_string(), "http://127.0.0.1:1235/v1".to_string()),
            ]
        );
        assert!(opencode_servers("not json {").is_empty());
        assert!(opencode_servers(r#"{"provider": []}"#).is_empty());
        let many: String =
            (0..20).map(|i| format!(r#""p{i}": {{"options": {{"baseURL": "http://localhost:{}/v1"}}}}"#, 9000 + i)).collect::<Vec<_>>().join(",");
        assert_eq!(opencode_servers(&format!(r#"{{"provider": {{{many}}}}}"#)).len(), OPENCODE_MAX);
        // Found the same way as a server at a usual address.
        let url = crate::tests::serve("200 OK", r#"{"object":"list","data":[{"id":"gemma"}]}"#);
        let found = opencode_servers(&format!(r#"{{"provider": {{"lmstudio": {{"name": "LM Studio", "options": {{"baseURL": "{url}"}}}}}}}}"#));
        let (label, base) = found.first().unwrap();
        assert_eq!(probe_local(label, base).unwrap().suggestion.name, "LM Studio from OpenCode (local)");
    }

    /// #73: LM Studio on another port was missed: its settings name the port, and the ports next to
    /// 1234 are probed too. Each address is probed once, under the most specific name.
    #[test]
    fn lm_studio_on_another_port_is_probed() {
        assert_eq!(lmstudio_port(r#"{"port": 1235, "networkInterface": "127.0.0.1", "cors": false}"#), Some(1235));
        for bad in ["", "not json", r#"{"port": 0}"#, r#"{"port": 70000}"#, r#"{"port": "1235"}"#, r#"{"cors": true}"#] {
            assert_eq!(lmstudio_port(bad), None, "{bad}");
        }
        let bases = |v: &[(String, String)]| v.iter().map(|(_, b)| b.clone()).collect::<Vec<_>>();
        let plain = servers_to_probe(None, Vec::new());
        let base_count = LOCAL_SERVERS.len();
        assert_eq!(plain.len(), base_count + LM_STUDIO_NEARBY.count(), "the usual servers, then the ports next to 1234");
        assert!(bases(&plain).contains(&"http://127.0.0.1:1235/v1".to_string()));
        // A port from LM Studio's settings, away from 1234, is probed as LM Studio.
        let moved = servers_to_probe(Some(4321), Vec::new());
        assert!(moved.contains(&("LM Studio".to_string(), "http://127.0.0.1:4321/v1".to_string())), "{moved:?}");
        // The usual port named again adds nothing; OpenCode's name for 1235 wins over the generic one.
        assert_eq!(servers_to_probe(Some(1234), Vec::new()).len(), plain.len());
        let from_opencode = servers_to_probe(None, vec![("LM Studio from OpenCode".into(), "http://127.0.0.1:1235/v1".into())]);
        assert_eq!(from_opencode.len(), plain.len(), "no address twice");
        assert!(from_opencode.contains(&("LM Studio from OpenCode".to_string(), "http://127.0.0.1:1235/v1".to_string())));
        // What answers on one of those ports is found like a server at a usual address.
        let url = crate::tests::serve("200 OK", r#"{"object":"list","data":[{"id":"gemma"}]}"#);
        assert_eq!(probe_local("LM Studio", &url).unwrap().suggestion.model, "gemma");
    }

    #[test]
    fn only_addresses_on_this_computer_or_network_count() {
        for url in [
            "http://localhost:1234/v1",
            "http://127.0.0.1/v1",
            "http://[::1]:8080",
            "http://[fe80::1]:11434/v1",
            "http://10.0.0.5:8000/v1",
            "https://studio.local:1234/v1",
            "http://172.20.0.2:1234",
            "http://ollama:11434/v1",
            "http://GPU-Box:8000",
            "http://gpu.lan:1234/v1",
            "http://studio.home.arpa/v1",
            "http://llm.internal:8080",
        ] {
            assert!(on_this_network(url), "{url}");
        }
        for url in [
            "https://api.openai.com/v1",
            "http://8.8.8.8/v1",
            "ftp://127.0.0.1",
            "127.0.0.1:1234",
            "",
            "http://",
            "https://lan.example.com",
            "https://internal.example.com/v1",
        ] {
            assert!(!on_this_network(url), "{url}");
        }
    }

    #[test]
    fn opencode_settings_are_found_where_opencode_keeps_them() {
        let d = tempfile::tempdir().unwrap();
        assert_eq!(opencode_config(|k| (k == "OPENCODE_CONFIG").then(|| "/x/oc.json".to_string()), None), Some(PathBuf::from("/x/oc.json")));
        assert_eq!(opencode_config(|_| None, Some(d.path().to_path_buf())), None, "nothing there");
        let dir = d.path().join(".config").join("opencode");
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(dir.join("opencode.json"), "{}").unwrap();
        assert_eq!(opencode_config(|_| None, Some(d.path().to_path_buf())), Some(dir.join("opencode.json")));
        std::fs::write(dir.join("opencode.jsonc"), "{}").unwrap();
        assert_eq!(opencode_config(|_| None, Some(d.path().to_path_buf())), Some(dir.join("opencode.jsonc")), "jsonc first");
        let xdg = d.path().join(".config").to_string_lossy().into_owned();
        assert_eq!(opencode_config(|k| (k == "XDG_CONFIG_HOME").then(|| xdg.clone()), None), Some(dir.join("opencode.jsonc")));
    }

    #[test]
    fn whole_scan_is_bounded() {
        let t = Instant::now();
        let _ = detect_all();
        assert!(t.elapsed() < TOTAL + Duration::from_millis(1500));
    }
}
