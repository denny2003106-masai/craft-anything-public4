//! Finding Ghidra and the Java it runs on, and getting both for the person once they agree:
//! pinned releases, each checked against its publisher's SHA-256 before anything is unpacked.

use craft_anything_evidence::{ErrorCode, ToolError};
use craft_anything_platform::process::Cancel;
use std::path::{Path, PathBuf};

/// Ghidra's engine id, as the engine table, Settings and every listing name it.
pub const ID: &str = "ghidra";
/// The engine store folder the Java for Ghidra is unpacked into; the Java runtime engine is found
/// there too (the engine table's `Install::Guided::folder`).
pub const JAVA_FOLDER: &str = "jdk";
/// The Ghidra release Craft Anything installs (it needs Java 21).
pub const VERSION: &str = "12.1.4";
/// What the person downloads, for the question we ask first (Ghidra 543 MB + Java 196 MB).
pub const DOWNLOAD_MB: u32 = 740;
/// Where to get Ghidra by hand when we can't install it here.
pub const PAGE: &str = "https://github.com/NationalSecurityAgency/ghidra/releases";

/// The host's pin for a guided engine (`ghidra`, `java`) from the engine table.
fn pin(id: &str) -> Option<&'static crate::Pin> {
    crate::engine(id).and_then(crate::ExternalEngine::host_pin)
}

/// Whether [`install`] works on this computer: Ghidra and its Java both have a pin here (Java is
/// pinned for Windows x64 and for Linux and macOS on x64 and arm64).
pub fn can_install() -> bool {
    pin(ID).is_some() && pin("java").is_some()
}

/// Ghidra's headless launcher: in the folder the person picked (Ghidra's own folder, or one that
/// holds it), then the managed install, then PATH, then where system packages put it, then the
/// folders where an unpacked copy is usually kept (#740).
pub fn headless(install_dir: Option<&Path>, store: &Path) -> Option<PathBuf> {
    headless_configured(install_dir, store)
        .or_else(|| crate::find_on_path(crate::engine(ID)?.host_exes()))
        .or_else(|| crate::well_known(ID).into_iter().find(|p| p.is_file()))
        .or_else(|| {
            let e = crate::engine(ID)?;
            crate::find_in_known_roots(ID, e.host_exes(), &e.known_root_folders())
        })
}

/// Ghidra's headless launcher in the folder the person picked or the managed install only: what
/// [`headless`] finds before it looks around the computer.
pub fn headless_configured(install_dir: Option<&Path>, store: &Path) -> Option<PathBuf> {
    if let Some(dir) = install_dir {
        let found = if dir.is_file() { launcher_from_file(dir) } else { in_root_or_child(dir, launcher) };
        if found.is_some() {
            return found;
        }
    }
    in_child(&store.join(ID), launcher)
}

/// Longest start script read when following one to its Ghidra folder.
const SCRIPT_CAP: u64 = 16 * 1024;
/// Most paths a start script names that are looked at on disk.
const SCRIPT_PATHS: usize = 32;

/// Ghidra's headless launcher from a file the person picked as Ghidra's folder. Whatever is returned
/// is run as the launcher, so it is only ever Ghidra's own `support/analyzeHeadless` or a script
/// that runs it:
/// - the file itself when it is that launcher (by name, as given, even through a link), or a script
///   naming that launcher (a wrapper that sets up Java first, say);
/// - else the launcher of the Ghidra folder the file is in, links followed (`ghidraRun` on PATH as
///   a link);
/// - else, for a start script such as the one Linux packages put on PATH
///   (`exec /opt/ghidra/ghidraRun "$@"`), the launcher of the Ghidra folder it names.
///
/// Anything else is `None`, so the setting isn't listed as Ghidra.
fn launcher_from_file(file: &Path) -> Option<PathBuf> {
    let exes = crate::engine(ID)?.host_exes();
    let is_launcher = |p: &Path| p.file_name().is_some_and(|n| exes.iter().any(|exe| n == *exe));
    let real = std::fs::canonicalize(file).ok()?;
    if is_launcher(file) || is_launcher(&real) {
        return Some(file.to_path_buf());
    }
    // A script that runs the launcher is kept before anything else, even in Ghidra's own folder.
    let named = named_in_script(&real).unwrap_or_default();
    if named.iter().any(|p| is_launcher(p) && p.is_file()) {
        return Some(file.to_path_buf());
    }
    let folder_of = |p: &Path| p.parent().and_then(|dir| launcher(dir).or_else(|| dir.parent().and_then(launcher)));
    // The path as given first, then where its links lead: on Windows `canonicalize` adds `\\?\`,
    // which batch files handle badly.
    let followed = |p: &Path| folder_of(p).or_else(|| folder_of(&std::fs::canonicalize(p).ok()?));
    if let Some(found) = folder_of(file).or_else(|| folder_of(&real)) {
        return Some(found);
    }
    named.iter().find_map(|p| if p.is_dir() { launcher(p) } else { followed(p) })
}

/// The absolute paths a short text file names that are on disk, as a start script names Ghidra's
/// folder (`None` when it is too long or isn't text). A quoted path is taken whole, spaces and all.
/// One level only: a script it names isn't read in turn.
fn named_in_script(file: &Path) -> Option<Vec<PathBuf>> {
    use std::io::Read;
    let mut bytes = Vec::new();
    std::fs::File::open(file).ok()?.take(SCRIPT_CAP + 1).read_to_end(&mut bytes).ok()?;
    if bytes.len() as u64 > SCRIPT_CAP || bytes.contains(&0) {
        return None;
    }
    let text = String::from_utf8(bytes).ok()?;
    // Between quotes first (odd pieces of a split on that quote), then word by word.
    let quoted = ['"', '\''].into_iter().flat_map(|q| text.split(q).skip(1).step_by(2));
    // `$GHIDRA_HOME/ghidraRun` after `GHIDRA_HOME=/opt/ghidra`: the assigned folder is named too.
    let words = text.split(|c: char| c.is_whitespace() || matches!(c, '"' | '\'' | '=' | ';' | '`' | '(' | ')'));
    let mut paths: Vec<PathBuf> = Vec::new();
    for p in quoted.chain(words).map(PathBuf::from).filter(|p| p.is_absolute()) {
        if !paths.contains(&p) {
            paths.push(p);
        }
        if paths.len() == SCRIPT_PATHS {
            break;
        }
    }
    paths.retain(|p| p.exists());
    Some(paths)
}

/// The Java runtime to run Ghidra with: the one the person set, else the managed one. `None` lets
/// Ghidra look for its own.
pub fn java_home(java_home: Option<&Path>, store: &Path) -> Option<PathBuf> {
    java_home.filter(|p| p.is_dir()).map(Path::to_path_buf).or_else(|| in_child(&store.join(JAVA_FOLDER), |d| has_java(d).then(|| d.to_path_buf())))
}

/// Download, check and unpack Java (unless one is already managed) and Ghidra into the engine
/// store, then point Ghidra at that Java. `progress` gets (what, bytes so far, total); a step with
/// no bytes (0, `None`) is setting up. Returns the headless launcher.
pub fn install(store: &Path, cancel: Option<Cancel>, progress: &dyn Fn(&str, u64, Option<u64>)) -> Result<PathBuf, ToolError> {
    // Ghidra is already on this computer, outside our store (PATH, a system package, an unzipped
    // copy in Downloads…): use it rather than download the same release again (#740).
    if let Some(found) = headless(None, store).filter(|p| !p.starts_with(store)) {
        return Ok(found);
    }
    let (Some(ghidra), Some(java)) = (pin(ID), pin("java")) else {
        return Err(ToolError::new(ErrorCode::NotSupported, "Ghidra can't be installed for you on this computer.")
            .with_remediation(format!("Install Ghidra {VERSION} from {PAGE}, then choose its folder in Settings → Engines.")));
    };
    if java_home(None, store).is_none() {
        fetch(java, store, JAVA_FOLDER, "Java runtime", cancel.clone(), progress)?;
    }
    fetch(ghidra, store, "ghidra", "Ghidra", cancel, progress)?;
    let exe =
        headless(None, store).ok_or_else(|| ToolError::new(ErrorCode::GarbledOutput, "Ghidra was unpacked, but its launcher wasn't where we expected."))?;
    if let (Some(java), Some(support)) = (java_home(None, store), exe.parent()) {
        point_at_java(&support.join("launch.properties"), &java)?;
    }
    Ok(exe)
}

/// One pinned archive: download beside the store (hashed as it streams; a mismatch deletes it),
/// unpack into a temporary folder and only then swap it in as `<store>/<folder>`.
fn fetch(pin: &crate::Pin, store: &Path, folder: &str, what: &str, cancel: Option<Cancel>, progress: &dyn Fn(&str, u64, Option<u64>)) -> Result<(), ToolError> {
    std::fs::create_dir_all(store).map_err(|e| ToolError::io(store.display(), e))?;
    let archive = store.join(format!(".{folder}.archive"));
    crate::install::download_verified(pin.url, &archive, pin.sha256, 1 << 30, cancel.as_ref(), &|got, total| progress(what, got, total))?;
    progress(&format!("Setting up {what}"), 0, None);
    let data = std::fs::read(&archive).map_err(|e| ToolError::io(archive.display(), e));
    let _ = std::fs::remove_file(&archive);
    let data = data?;
    let incoming = store.join(format!(".{folder}.incoming"));
    let _ = std::fs::remove_dir_all(&incoming);
    let dest = store.join(folder);
    let swapped = crate::install::unpack(&data, pin.format, &incoming, pin.strip_prefix, cancel.as_ref(), &|_| {}).and_then(|_| {
        let _ = std::fs::remove_dir_all(&dest);
        std::fs::rename(&incoming, &dest).map_err(|e| ToolError::io(dest.display(), e))
    });
    if swapped.is_err() {
        let _ = std::fs::remove_dir_all(&incoming);
    }
    swapped
}

/// Ghidra's supported way to choose its Java: `JAVA_HOME_OVERRIDE` in support/launch.properties.
fn point_at_java(props: &Path, java: &Path) -> Result<(), ToolError> {
    // Forward slashes: Ghidra reads this file without escapes, and Java takes them on Windows too.
    let line = format!("JAVA_HOME_OVERRIDE={}", java.display().to_string().replace('\\', "/"));
    let old = std::fs::read_to_string(props).unwrap_or_default();
    let mut lines: Vec<String> = old.lines().filter(|l| !l.trim_start().starts_with("JAVA_HOME_OVERRIDE")).map(str::to_string).collect();
    lines.push(line);
    std::fs::write(props, lines.join("\n") + "\n").map_err(|e| ToolError::io(props.display(), e))
}

/// The Java Ghidra will run on, found the way its launcher looks: a working `JAVA_HOME_OVERRIDE`
/// in its `support/launch.properties` first, then the `JAVA_HOME` it's started with, then a `java`
/// on PATH.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum GhidraJava {
    /// `JAVA_HOME_OVERRIDE` in Ghidra's launch.properties (a guided install writes it).
    Override(PathBuf),
    /// The `JAVA_HOME` Ghidra is started with: the one set for it (`configured`), or the one this
    /// program was started with.
    Home { dir: PathBuf, configured: bool },
    /// A `java` on PATH.
    OnPath(PathBuf),
    /// The folder set as Ghidra's Java has no `bin/java`.
    NotJava(PathBuf),
    /// No Java at all.
    Missing,
}

/// Which Java the Ghidra at `launcher` will run on. `configured` is the Java set for it
/// (`Settings::ghidra_java`), `inherited` the `JAVA_HOME` this program has.
pub fn java_in_use(launcher: &Path, configured: Option<&Path>, inherited: Option<&Path>) -> GhidraJava {
    // Ghidra's launcher follows a link to itself (one on PATH) and reads the properties beside
    // the real one.
    let launcher = std::fs::canonicalize(launcher).unwrap_or_else(|_| launcher.to_path_buf());
    let props = launcher.parent().map(|d| d.join("launch.properties"));
    let over = props.and_then(|p| std::fs::read_to_string(p).ok()).and_then(|text| java_override(&text, &|k| std::env::var(k).ok()));
    if let Some(dir) = over.filter(|d| has_java(d)) {
        return GhidraJava::Override(dir);
    }
    match configured {
        Some(dir) if has_java(dir) => return GhidraJava::Home { dir: dir.to_path_buf(), configured: true },
        Some(dir) => return GhidraJava::NotJava(dir.to_path_buf()),
        None => {}
    }
    if let Some(dir) = inherited.filter(|d| has_java(d)) {
        return GhidraJava::Home { dir: dir.to_path_buf(), configured: false };
    }
    match crate::find_on_path(&[if cfg!(windows) { "java.exe" } else { "java" }]) {
        Some(p) => GhidraJava::OnPath(p),
        None => GhidraJava::Missing,
    }
}

/// The `JAVA_HOME_OVERRIDE` in Ghidra's launch.properties text, read the way Ghidra does: `KEY=value`
/// with or without spaces around the `=`, the first one with a value, and `${NAME}` replaced by
/// that environment variable (`env`; an unset one becomes nothing).
fn java_override(text: &str, env: &dyn Fn(&str) -> Option<String>) -> Option<PathBuf> {
    let value =
        text.lines().filter_map(|l| l.split_once('=')).filter(|(k, _)| k.trim() == "JAVA_HOME_OVERRIDE").map(|(_, v)| v.trim()).find(|v| !v.is_empty())?;
    let mut out = String::new();
    let mut rest = value;
    while let Some(start) = rest.find("${") {
        out.push_str(rest.get(..start).unwrap_or_default());
        let after = rest.get(start + 2..).unwrap_or_default();
        let Some(end) = after.find('}') else {
            // No closing brace: the rest is taken as it is.
            out.push_str(rest.get(start..).unwrap_or_default());
            rest = "";
            break;
        };
        out.push_str(&env(after.get(..end).unwrap_or_default()).unwrap_or_default());
        rest = after.get(end + 1..).unwrap_or_default();
    }
    out.push_str(rest);
    Some(PathBuf::from(out)).filter(|p| !p.as_os_str().is_empty())
}

fn launcher(root: &Path) -> Option<PathBuf> {
    let names: &[&str] = if cfg!(windows) { &["analyzeHeadless.bat"] } else { &["analyzeHeadless"] };
    names.iter().map(|n| root.join("support").join(n)).find(|p| p.is_file())
}

fn has_java(dir: &Path) -> bool {
    dir.join("bin").join(if cfg!(windows) { "java.exe" } else { "java" }).is_file()
}

/// `find` on `dir` itself, else on its sub-folders (a zip unpacks into one top folder).
fn in_root_or_child(dir: &Path, find: impl Fn(&Path) -> Option<PathBuf>) -> Option<PathBuf> {
    find(dir).or_else(|| in_child(dir, find))
}

fn in_child(dir: &Path, find: impl Fn(&Path) -> Option<PathBuf>) -> Option<PathBuf> {
    let mut subs: Vec<PathBuf> = std::fs::read_dir(dir).ok()?.flatten().map(|e| e.path()).filter(|p| p.is_dir()).collect();
    subs.sort();
    subs.iter().rev().find_map(|d| find(d))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn touch(p: &Path) {
        std::fs::create_dir_all(p.parent().unwrap()).unwrap();
        std::fs::write(p, b"x").unwrap();
    }

    #[test]
    fn a_macos_jdk_unpacks_to_a_java_home_we_find() {
        use craft_anything_testkit::firmware as fx;
        let pin = crate::engine("java").and_then(|e| e.pin_for("macos", "aarch64")).unwrap();
        let java = if cfg!(windows) { "java.exe" } else { "java" };
        let tar = fx::tar_entries(&[
            ("jdk-21.0.12.1+1/Contents/Info.plist", b'0', b"<plist/>", ""),
            (&format!("jdk-21.0.12.1+1/Contents/Home/bin/{java}"), b'0', b"java", ""),
            ("jdk-21.0.12.1+1/Contents/Home/lib/modules", b'0', b"m", ""),
        ]);
        let store = tempfile::tempdir().unwrap();
        let jdk = store.path().join("jdk");
        crate::install::unpack(&fx::gzip(&tar, None), pin.format, &jdk, pin.strip_prefix, None, &|_| {}).unwrap();
        assert_eq!(java_home(None, store.path()), Some(jdk.join("Home")));
        let linux = crate::engine("java").and_then(|e| e.pin_for("linux", "x86_64")).unwrap();
        assert_eq!((linux.format, linux.strip_prefix), (crate::ArchiveFormat::TarGz, None), "Linux keeps jdk-…/bin/java, one folder down");
    }

    /// Ghidra's folder holds both scripts; the `.bat` can't start off Windows (#1084).
    #[test]
    fn the_launcher_looked_for_on_path_is_this_systems_own() {
        let exes = crate::engine(ID).unwrap().host_exes();
        assert_eq!(exes, [if cfg!(windows) { "analyzeHeadless.bat" } else { "analyzeHeadless" }]);
    }

    #[test]
    fn finds_ghidra_and_java_where_they_really_live() {
        let d = tempfile::tempdir().unwrap();
        let store = d.path().join("store");
        let exe = if cfg!(windows) { "analyzeHeadless.bat" } else { "analyzeHeadless" };
        // None, unless this computer has Ghidra on PATH or from a system package.
        let installed = crate::find_on_path(&[exe]).is_some() || crate::well_known(ID).iter().any(|p| p.is_file());
        assert!(headless(None, &store).is_none() || installed);
        // The managed install: the zip's own top folder under <store>/ghidra.
        let managed = store.join("ghidra/ghidra_12.1.4_PUBLIC/support").join(exe);
        touch(&managed);
        assert_eq!(headless(None, &store), Some(managed));
        // A folder the person picked wins, whether it's Ghidra's folder or the one holding it.
        let own = d.path().join("tools/ghidra_11.4/support").join(exe);
        touch(&own);
        assert_eq!(headless(Some(&d.path().join("tools/ghidra_11.4")), &store), Some(own.clone()));
        assert_eq!(headless(Some(&d.path().join("tools")), &store), Some(own));

        assert!(java_home(None, &store).is_none());
        let jdk = store.join("jdk/jdk-21.0.12.1+1");
        touch(&jdk.join("bin").join(if cfg!(windows) { "java.exe" } else { "java" }));
        assert_eq!(java_home(None, &store), Some(jdk));
        assert_eq!(java_home(Some(d.path()), &store).as_deref(), Some(d.path()), "a Java the person set wins");
    }

    const EXE: &str = if cfg!(windows) { "analyzeHeadless.bat" } else { "analyzeHeadless" };

    /// A Ghidra folder as its zip unpacks: `ghidraRun` at the top, the headless launcher in `support/`.
    fn ghidra_folder(at: &Path) -> PathBuf {
        touch(&at.join("ghidraRun"));
        let exe = at.join("support").join(EXE);
        touch(&exe);
        exe
    }

    fn same(a: Option<PathBuf>, b: &Path) -> bool {
        a.and_then(|a| std::fs::canonicalize(a).ok()) == std::fs::canonicalize(b).ok()
    }

    /// A Ghidra setting that names a file is run as Ghidra's headless launcher, so it has to be one.
    #[test]
    fn a_setting_naming_the_launcher_itself_is_that_launcher() {
        let d = tempfile::tempdir().unwrap();
        let exe = ghidra_folder(&d.path().join("ghidra_12.1.4_PUBLIC"));
        assert_eq!(headless_configured(Some(&exe), &d.path().join("store")), Some(exe));
    }

    /// Arch's package puts a start script on PATH that runs `/opt/ghidra/ghidraRun`, Ghidra's window,
    /// not its headless launcher: picked as the setting, it was listed as found and Deep mode
    /// quietly used the built-in decompiler.
    #[test]
    fn a_start_script_is_followed_to_the_ghidra_folder_it_names() {
        let d = tempfile::tempdir().unwrap();
        let root = d.path().join("opt").join("My Ghidra");
        let exe = ghidra_folder(&root);
        let script = d.path().join("bin").join("ghidra");
        let store = d.path().join("store");
        let mut bodies = vec![
            format!("#!/bin/sh\nexec \"{}\" \"$@\"\n", root.join("ghidraRun").display()),
            format!("#!/bin/sh\nGHIDRA_HOME='{}'\nexec \"$GHIDRA_HOME/ghidraRun\" \"$@\"\n", root.display()),
        ];
        let plain = d.path().join("opt").join("ghidra");
        if !plain.display().to_string().contains(' ') {
            ghidra_folder(&plain);
            bodies.push(format!("#!/bin/sh\nexec {}/ghidraRun \"$@\"\n", plain.display()));
        }
        for body in bodies {
            touch(&script);
            std::fs::write(&script, &body).unwrap();
            let found = headless_configured(Some(&script), &store);
            assert!(same(found.clone(), &exe) || same(found, &plain.join("support").join(EXE)), "{body}");
            assert!(!headless_configured(Some(&script), &store).unwrap().display().to_string().starts_with(r"\\?\"));
        }
        // Too long to be a start script: not read.
        std::fs::write(&script, format!("{}\nexec \"{}\"\n", "#".repeat(SCRIPT_CAP as usize), root.join("ghidraRun").display())).unwrap();
        assert_eq!(headless_configured(Some(&script), &store), None);
    }

    /// A script that runs the headless launcher itself (setting up Java first, say) is run as it is.
    #[test]
    fn a_wrapper_around_the_launcher_is_kept() {
        let d = tempfile::tempdir().unwrap();
        let exe = ghidra_folder(&d.path().join("ghidra"));
        let wrapper = d.path().join("bin").join("ghidra-headless");
        touch(&wrapper);
        std::fs::write(&wrapper, format!("#!/bin/sh\nJAVA_HOME=/jdk exec \"{}\" \"$@\"\n", exe.display())).unwrap();
        assert_eq!(headless_configured(Some(&wrapper), &d.path().join("store")), Some(wrapper));
        // Also when it sits in Ghidra's own folder, beside `ghidraRun`.
        let beside = d.path().join("ghidra").join("headless-with-java");
        std::fs::write(&beside, format!("#!/bin/sh\nJAVA_HOME=/jdk exec \"{}\" \"$@\"\n", exe.display())).unwrap();
        assert_eq!(headless_configured(Some(&beside), &d.path().join("store")), Some(beside));
    }

    /// A start script that runs a link onto PATH (`exec /usr/bin/ghidraRun`) leads to where it points.
    #[cfg(unix)]
    #[test]
    fn a_start_script_naming_a_link_is_followed_through_it() {
        let d = tempfile::tempdir().unwrap();
        let exe = ghidra_folder(&d.path().join("opt").join("ghidra"));
        let bin = d.path().join("usr").join("bin");
        std::fs::create_dir_all(&bin).unwrap();
        std::os::unix::fs::symlink(d.path().join("opt").join("ghidra").join("ghidraRun"), bin.join("ghidraRun")).unwrap();
        let script = d.path().join("ghidra");
        std::fs::write(&script, format!("#!/bin/sh\nexec \"{}\" \"$@\"\n", bin.join("ghidraRun").display())).unwrap();
        assert!(same(headless_configured(Some(&script), &d.path().join("store")), &exe));
    }

    #[test]
    fn a_file_that_leads_to_no_ghidra_is_not_ghidra() {
        let d = tempfile::tempdir().unwrap();
        let store = d.path().join("store");
        let notes = d.path().join("notes.txt");
        std::fs::write(&notes, "nothing to see").unwrap();
        assert_eq!(headless_configured(Some(&notes), &store), None);
        let script = d.path().join("ghidra");
        std::fs::write(&script, format!("#!/bin/sh\nexec {}/ghidraRun \"$@\"\n", d.path().join("gone").display())).unwrap();
        assert_eq!(headless_configured(Some(&script), &store), None);
        std::fs::write(&script, [0xff, 0xfe, 0x00, 0x2f]).unwrap();
        assert_eq!(headless_configured(Some(&script), &store), None, "not text");
        // With nothing usable set, the managed install is still found.
        let managed = ghidra_folder(&store.join(ID).join("ghidra_12.1.4_PUBLIC"));
        assert_eq!(headless_configured(Some(&notes), &store), Some(managed));
    }

    /// Homebrew and some packages link `ghidraRun` onto PATH instead.
    #[cfg(unix)]
    #[test]
    fn a_link_to_ghidras_start_script_is_followed_to_its_folder() {
        let d = tempfile::tempdir().unwrap();
        let root = d.path().join("Caskroom").join("ghidra_12.1.4_PUBLIC");
        let exe = ghidra_folder(&root);
        let bin = d.path().join("bin");
        std::fs::create_dir_all(&bin).unwrap();
        std::os::unix::fs::symlink(root.join("ghidraRun"), bin.join("ghidraRun")).unwrap();
        assert!(same(headless_configured(Some(&bin.join("ghidraRun")), &d.path().join("store")), &exe));
        std::os::unix::fs::symlink(&exe, bin.join(EXE)).unwrap();
        assert_eq!(headless_configured(Some(&bin.join(EXE)), &d.path().join("store")), Some(bin.join(EXE)), "a linked launcher is kept as given");
    }

    #[test]
    fn the_java_override_is_read_as_ghidra_reads_it() {
        let env = |k: &str| (k == "JDK_HOME").then(|| "/opt/jdk-25".to_string());
        let read = |t: &str| java_override(t, &env);
        assert_eq!(read("JAVA_HOME_OVERRIDE=/a\nJAVA_HOME_OVERRIDE=/b\n"), Some(PathBuf::from("/a")), "the first one");
        assert_eq!(read("JAVA_HOME_OVERRIDE=\nJAVA_HOME_OVERRIDE = /b\n"), Some(PathBuf::from("/b")), "the first with a value");
        assert_eq!(read("JAVA_HOME_OVERRIDE=${JDK_HOME}\n"), Some(PathBuf::from("/opt/jdk-25")));
        assert_eq!(read("JAVA_HOME_OVERRIDE=${JDK_HOME}/x/${NOPE}y\n"), Some(PathBuf::from("/opt/jdk-25/x/y")));
        assert_eq!(read("JAVA_HOME_OVERRIDE=${NOPE}\n"), None, "an unset variable leaves no path");
        assert_eq!(read("JAVA_HOME_OVERRIDE=/a${JDK\n"), Some(PathBuf::from("/a${JDK")));
        assert_eq!(read("VMARGS=-Xshare:off\n"), None);
    }

    #[cfg(unix)]
    #[test]
    fn a_launcher_reached_through_a_link_reads_the_real_installs_properties() {
        let d = tempfile::tempdir().unwrap();
        let support = d.path().join("ghidra").join("support");
        let jdk = d.path().join("jdk");
        std::fs::create_dir_all(&support).unwrap();
        std::fs::create_dir_all(jdk.join("bin")).unwrap();
        std::fs::write(jdk.join("bin").join("java"), "").unwrap();
        std::fs::write(support.join("analyzeHeadless"), "").unwrap();
        std::fs::write(support.join("launch.properties"), format!("JAVA_HOME_OVERRIDE={}\n", jdk.display())).unwrap();
        let bin = d.path().join("bin");
        std::fs::create_dir_all(&bin).unwrap();
        std::os::unix::fs::symlink(support.join("analyzeHeadless"), bin.join("analyzeHeadless")).unwrap();
        let canon = std::fs::canonicalize(&jdk).unwrap();
        assert!(matches!(java_in_use(&bin.join("analyzeHeadless"), None, None), GhidraJava::Override(p) if p == jdk || p == canon));
    }

    #[test]
    fn ghidra_is_pointed_at_our_java() {
        let d = tempfile::tempdir().unwrap();
        let props = d.path().join("launch.properties");
        std::fs::write(&props, "VMARGS=-Xshare:off\nJAVA_HOME_OVERRIDE=\n").unwrap();
        point_at_java(&props, Path::new(r"C:\store\jdk\jdk-21")).unwrap();
        let text = std::fs::read_to_string(&props).unwrap();
        assert_eq!(text, "VMARGS=-Xshare:off\nJAVA_HOME_OVERRIDE=C:/store/jdk/jdk-21\n");
    }

    #[test]
    fn pins_come_from_the_engine_table() {
        // Checksum handling is tested once, in `install` (download_verified).
        let ghidra = crate::engine("ghidra").unwrap().pins();
        assert!(ghidra.iter().all(|p| p.url.contains(VERSION)));
        let java_pinned = cfg!(any(
            all(windows, target_arch = "x86_64"),
            all(any(target_os = "linux", target_os = "macos"), any(target_arch = "x86_64", target_arch = "aarch64"))
        ));
        assert_eq!(can_install(), java_pinned);
    }
}
